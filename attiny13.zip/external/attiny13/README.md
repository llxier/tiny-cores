# attiny13
ATtiny13 microcontroller support for the Arduino software (http://arduino.cc). For Arduino 1.6.x.

To install:

* Open Arduino
* Go To Preferences
* Add https://github.com/samw3/attiny13/blob/master/package_samw3_attiny13_index.json to "Additional Boards Manager URLs"
* Select: Tools -> Board -> Board Manager...
* Find attiny13 in the list
* Highlight and click Install
